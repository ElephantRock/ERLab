/**
 * Knowledge Graph API client — BATCH-25/TASK-02
 *
 * Provides typed functions for the knowledge graph endpoints:
 *   GET /knowledge-graph/stats
 *   GET /knowledge-graph/entities?type=...&search=...&limit=100
 *   GET /knowledge-graph/entity/{id}
 *   GET /knowledge-graph/subgraph/{id}?depth=2
 */

import { callContract } from "./contracts/common";
import {
  getEntitiesContract,
  getGraphStatsContract,
  getWorldModelContract,
} from "./contracts/f1-3a-reads";
import { getEntityContract, getSubgraphContract } from "./contracts/knowledge-graph";

// ── Types ─────────────────────────────────────────────────────────

export interface GraphStats {
  entity_count: number;
  relationship_count: number;
  entity_types: Record<string, number>;
  relation_types: Record<string, number>;
}

export interface TruthInfo {
  confidence: number;
  frequency: number;
  source_count: number;
}

export interface GraphEntity {
  id: string;
  entity_type: string;
  name: string;
  aliases: string[];
  properties: Record<string, unknown>;
  truth: TruthInfo;
}

export interface GraphRelationship {
  source_id: string;
  target_id: string;
  relation_type: string;
  weight: number;
  evidence: string[];
  truth: TruthInfo;
}

export interface EntityDetail {
  entity: GraphEntity;
  relationships: GraphRelationship[];
}

export interface Subgraph {
  entities: GraphEntity[];
  relationships: GraphRelationship[];
}

export interface WorldModel {
  total_entities: number;
  total_relationships: number;
  entity_type_distribution: Record<string, number>;
  relationship_type_distribution: Record<string, number>;
  top_entities: GraphEntity[];
  strongest_relationships: GraphRelationship[];
}

// ── API Functions ─────────────────────────────────────────────────

/** GET /knowledge-graph/stats → graph statistics */
export function getGraphStats(): Promise<GraphStats> {
  // F1.3a: migrated from apiFetchUnchecked to callContract with runtime decoder
  return callContract(getGraphStatsContract);
}

/** GET /knowledge-graph/entities → entity list with optional filters (HB-02: max 100) */
export function getEntities(params?: {
  type?: string;
  search?: string;
  limit?: number;
}): Promise<GraphEntity[]> {
  // F1.3a: migrated from apiFetchUnchecked to callContract with runtime decoder
  return callContract(getEntitiesContract, { query: params });
}

/** GET /knowledge-graph/entity/{id} → entity with relationships */
export function getEntity(id: string): Promise<EntityDetail> {
  // Encode the id here: callContract's buildPath substitutes {id} verbatim
  // (it does not URI-encode), so we preserve the pre-migration
  // encodeURIComponent behavior for IDs that may contain reserved chars.
  return callContract(getEntityContract, { params: { id: encodeURIComponent(id) } });
}

/** GET /knowledge-graph/subgraph/{id}?depth=N → connected subgraph */
export function getSubgraph(id: string, depth = 2): Promise<Subgraph> {
  return callContract(getSubgraphContract, {
    params: { id: encodeURIComponent(id) },
    query: { depth },
  });
}

/** GET /knowledge-graph/world-model → high-level world model summary */
export function getWorldModel(): Promise<WorldModel> {
  // F1.3a: migrated from apiFetchUnchecked to callContract with runtime decoder
  return callContract(getWorldModelContract);
}
