import { useState, useEffect } from "react";
import {
  triggerAutonomous,
  getAutonomousHistory,
  stopAutonomousCycle,
  getEvolutionStatus,
  startScheduler,
  stopScheduler,
  getSchedulerStatus,
  type EvolutionStatus,
  type SchedulerStatus,
} from "@/api/autonomous";
import { CycleProgress } from "@/components/autonomous/cycle-progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Cpu, Loader2, Play, StopCircle, Clock, Activity } from "lucide-react";
import { ErrorCard } from "@/components/ui/error-card";
import { EmptyState } from "@/components/ui/empty-state";
import type { AutonomousCycleHistoryEntry } from "@/api/autonomous";

export default function AutonomousPage() {
  const [cycles, setCycles] = useState<AutonomousCycleHistoryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isStarting, setIsStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [domain, setDomain] = useState("AI/NLP");
  const [maxRuns, setMaxRuns] = useState(3);
  const [stopConfirmId, setStopConfirmId] = useState<string | null>(null);
  // Mutation 26: pending state for the stop confirmation button
  const [isStopping, setIsStopping] = useState(false);

  // Scheduler + evolution state
  const [schedulerStatus, setSchedulerStatus] = useState<SchedulerStatus | null>(null);
  const [evolutionStatus, setEvolutionStatus] = useState<EvolutionStatus | null>(null);
  const [schedulerLoading, setSchedulerLoading] = useState(false);
  const [schedulerError, setSchedulerError] = useState<string | null>(null);

  useEffect(() => {
    loadHistory();
    loadSchedulerAndEvolution();
  }, []);

  async function loadHistory() {
    try {
      const data = await getAutonomousHistory();
      setCycles(data.cycles);
    } catch {
      setError("Failed to load history");
    } finally {
      setIsLoading(false);
    }
  }

  async function loadSchedulerAndEvolution() {
    try {
      const [sched, evo] = await Promise.all([
        getSchedulerStatus(),
        getEvolutionStatus(),
      ]);
      setSchedulerStatus(sched);
      setEvolutionStatus(evo);
      setSchedulerError(null);
    } catch {
      setSchedulerError("Failed to load scheduler and evolution status");
    }
  }

  async function handleSchedulerStart() {
    setSchedulerLoading(true);
    setError(null);
    try {
      await startScheduler();
      await loadSchedulerAndEvolution();
    } catch {
      setError("Failed to start scheduler");
    } finally {
      setSchedulerLoading(false);
    }
  }

  async function handleSchedulerStop() {
    setSchedulerLoading(true);
    setError(null);
    try {
      await stopScheduler();
      await loadSchedulerAndEvolution();
    } catch {
      setError("Failed to stop scheduler");
    } finally {
      setSchedulerLoading(false);
    }
  }

  async function handleStart() {
    setIsStarting(true);
    setError(null);
    try {
      await triggerAutonomous({ domain, max_runs: maxRuns });
      await loadHistory();
    } catch {
      setError("Failed to start cycle");
    } finally {
      setIsStarting(false);
    }
  }

  function handleStopRequest(cycleId: string) {
    // HB-01: Require confirmation before stopping
    setStopConfirmId(cycleId);
  }

  async function handleStopConfirm(cycleId: string) {
    // Mutation 26: prevent duplicate submission while pending
    if (isStopping) return;
    setIsStopping(true);
    try {
      await stopAutonomousCycle(cycleId);
      // Close the dialog only AFTER the stop succeeds — on failure the
      // dialog stays open with an error so the user can retry.
      setStopConfirmId(null);
      await loadHistory();
    } catch {
      setError("Failed to stop cycle");
    } finally {
      setIsStopping(false);
    }
  }

  function handleStopCancel() {
    // Don't allow cancel while the stop request is mid-flight
    if (isStopping) return;
    setStopConfirmId(null);
  }

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4" data-testid="autonomous-loading">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        <p className="text-muted-foreground">Loading autonomous cycles...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="autonomous-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Autonomous Cycles</h1>
          <p className="text-muted-foreground">Monitor and control autonomous research cycles.</p>
        </div>
      </div>

      {error && (
        <ErrorCard message={error} testId="autonomous-error" />
      )}

      {/* Start Cycle Form */}
      <Card data-testid="autonomous-start-form">
        <CardHeader>
          <CardTitle>Start New Cycle</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <label className="text-sm font-medium" data-testid="domain-label">Domain</label>
              <input
                type="text"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                data-testid="domain-input"
              />
            </div>
            <div className="w-32">
              <label className="text-sm font-medium">Max Runs</label>
              <input
                type="number"
                value={maxRuns}
                onChange={(e) => setMaxRuns(Number(e.target.value))}
                min={1}
                max={20}
                className="mt-1 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                data-testid="max-runs-input"
              />
            </div>
            <Button
              onClick={handleStart}
              disabled={isStarting}
              data-testid="start-cycle-btn"
            >
              {isStarting ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              {isStarting ? "Starting..." : "Start Cycle"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Scheduler Controls */}
      <Card data-testid="scheduler-controls">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Scheduler
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {schedulerError && (
            <div
              className="text-sm text-destructive"
              data-testid="scheduler-status-error"
            >
              {schedulerError}
            </div>
          )}
          <div className="flex items-center gap-2 text-sm">
            <span className="font-medium">Status:</span>
            <span data-testid="scheduler-status-text">
              {schedulerStatus?.status ?? "unknown"}
            </span>
          </div>
          {schedulerStatus?.status === "running" && schedulerStatus.next_run && (
            <div className="flex items-center gap-2 text-sm">
              <span className="font-medium">Next Run:</span>
              <span>{new Date(schedulerStatus.next_run).toLocaleString()}</span>
            </div>
          )}
          <div className="flex items-center gap-3">
            <Button
              onClick={handleSchedulerStart}
              disabled={schedulerLoading || schedulerStatus?.status === "running"}
              variant="outline"
              data-testid="scheduler-start-btn"
            >
              {schedulerLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Play className="h-4 w-4 mr-2" />}
              Start Scheduler
            </Button>
            <Button
              onClick={handleSchedulerStop}
              disabled={schedulerLoading || schedulerStatus?.status !== "running"}
              variant="destructive"
              data-testid="scheduler-stop-btn"
            >
              <StopCircle className="h-4 w-4 mr-2" />
              Stop Scheduler
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Evolution Status */}
      <Card data-testid="evolution-status-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            Evolution Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-medium">Enabled:</span>
              <span data-testid="evolution-enabled">
                {evolutionStatus?.enabled ? "Yes" : "No"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium">Overlays:</span>
              <span data-testid="evolution-overlays">
                {evolutionStatus?.overlays_generated ?? 0}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium">Recent Outcomes:</span>
              <span data-testid="evolution-outcomes">
                {evolutionStatus?.recent_outcomes?.length ?? 0}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stop Confirmation (HB-01) */}
      {stopConfirmId && (
        <Card className="border-warning" data-testid="stop-confirm-dialog">
          <CardContent className="p-4">
            <p className="text-sm font-medium mb-3">
              Are you sure you want to stop cycle <code className="text-xs">{stopConfirmId}</code>?
            </p>
            <div className="flex gap-2">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleStopConfirm(stopConfirmId)}
                disabled={isStopping}
                data-testid="stop-confirm-btn"
              >
                {isStopping ? (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                ) : (
                  <StopCircle className="h-4 w-4 mr-1" />
                )}
                {isStopping ? "Stopping..." : "Confirm Stop"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleStopCancel}
                disabled={isStopping}
                data-testid="stop-cancel-btn"
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* History List */}
      <div>
        <h2 className="text-lg font-semibold mb-3" data-testid="history-heading">Cycle History</h2>
        {cycles.length === 0 ? (
          <EmptyState
            icon={Cpu}
            title="No autonomous cycles yet"
            message="Start one above to begin automated research."
            testId="autonomous-empty"
          />
        ) : (
          <div className="space-y-3" data-testid="autonomous-history-list">
            {cycles.map((cycle) => (
              <CycleProgress
                key={cycle.cycle_id}
                cycle={cycle}
                onStop={handleStopRequest}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
